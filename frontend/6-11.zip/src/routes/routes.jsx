import { Routes, Route } from "react-router-dom";
import ProtectedRoute from "./ProtectedRoute";
import AllPatient from "../pages/AllPatient";
import AddNewPatient from "../pages/AddNewPatient";
import NewEncounter from "../pages/NewEncounter";
import Statement from "../pages/Statement";
import RefundsNew from "../pages/RefundsNew";
import BulkEligibility from "../pages/BulkEligibility";
import Login from "../pages/Login";
import ConfirmPatientList from "../pages/ConfirmPatientList";
import PreBilling from "../pages/PreBilling";
import PreBillingClaim from "../pages/PreBillingClaim";
import PostBillingClaimPage from "../pages/PostBillingClaimPage";

import NewPayment from "../pages/NewPayment";

import Summary from "../pages/Summary";
import AIInsight from "../pages/AIInsight";
import MyTask from "../pages/MyTask";
import PerformanceOverview from "../pages/PerformanceOverview";

import ReferringProvider from "../pages/ReferringProvider";
import ReferringProviderEdit from "../pages/ReferringProviderEdit";
import RenderingProvider from "../pages/RenderingProvider";
import Locations from "../pages/Locations";
import LocationsEdit from "../pages/LocationsEdit";
import Practice from "../pages/Practice";
import PracticeEdit from "../pages/PracticeEdit";
import Fee from "../pages/Fee";
import FeeConfiguration from "../pages/FeeConfiguration";
import InsuranceProvider from "../pages/InsuranceProvider";
import InsuranceProviderEdit from "../pages/InsuranceProviderEdit";
import Program from "../pages/Program";

import PostBillingEditPage from "../pages/PostBillingEditPage";
import RemittanceERAEdit from "../pages/RemittanceERAEdit";

const AppRoutes = () => {
  return (
    <Routes>
      {/* Public Route */}
      <Route path="/login" element={<Login />} />

      {/* Protected Routes */}

      <Route
        path="/"
        element={
          <ProtectedRoute>
            <div style={{ padding: "24px" }}>Welcome to TiaSTAT</div>
          </ProtectedRoute>
        }
      />
      <Route
        path="/summary"
        element={
          <ProtectedRoute>
            <Summary />
          </ProtectedRoute>
        }
      />
      <Route
        path="/ai-insights"
        element={
          <ProtectedRoute>
            <AIInsight />
          </ProtectedRoute>
        }
      />
      <Route
        path="/my-tasks"
        element={
          <ProtectedRoute>
            <MyTask />
          </ProtectedRoute>
        }
      />
      <Route
        path="/performance-overview"
        element={
          <ProtectedRoute>
            <PerformanceOverview />
          </ProtectedRoute>
        }
      />
      <Route
        path="/referring-provider"
        element={
          <ProtectedRoute>
            <ReferringProvider />
          </ProtectedRoute>
        }
      />
      <Route
        path="/referring-provider/edit"
        element={
          <ProtectedRoute>
            <ReferringProviderEdit />
          </ProtectedRoute>
        }
      />
      <Route
        path="/rendering-provider"
        element={
          <ProtectedRoute>
            <RenderingProvider />
          </ProtectedRoute>
        }
      />
      <Route
        path="/locations"
        element={
          <ProtectedRoute>
            <Locations />
          </ProtectedRoute>
        }
      />
      <Route
        path="/locations/edit"
        element={
          <ProtectedRoute>
            <LocationsEdit />
          </ProtectedRoute>
        }
      />
      <Route
        path="/practice"
        element={
          <ProtectedRoute>
            <Practice />
          </ProtectedRoute>
        }
      />
      <Route
        path="/practice/edit"
        element={
          <ProtectedRoute>
            <PracticeEdit />
          </ProtectedRoute>
        }
      />
      <Route
        path="/fee"
        element={
          <ProtectedRoute>
            <Fee />
          </ProtectedRoute>
        }
      />
      <Route
        path="/fee/configuration"
        element={
          <ProtectedRoute>
            <FeeConfiguration />
          </ProtectedRoute>
        }
      />
      <Route
        path="/insurance-provider"
        element={
          <ProtectedRoute>
            <InsuranceProvider />
          </ProtectedRoute>
        }
      />
      <Route
        path="/insurance-provider/edit"
        element={
          <ProtectedRoute>
            <InsuranceProviderEdit />
          </ProtectedRoute>
        }
      />
      <Route
        path="/program"
        element={
          <ProtectedRoute>
            <Program />
          </ProtectedRoute>
        }
      />
      <Route
        path="/add-patient"
        element={
          <ProtectedRoute>
            <AllPatient />
          </ProtectedRoute>
        }
      />
      <Route
        path="/patient-list"
        element={
          <ProtectedRoute>
            <ConfirmPatientList />
          </ProtectedRoute>
        }
      />
      <Route
        path="/add-new-patient"
        element={
          <ProtectedRoute>
            <AddNewPatient />
          </ProtectedRoute>
        }
      />
      <Route
        path="/statement"
        element={
          <ProtectedRoute>
            <Statement />
          </ProtectedRoute>
        }
      />
      <Route
        path="/refunds"
        element={
          <ProtectedRoute>
            <RefundsNew />
          </ProtectedRoute>
        }
      />
      <Route
        path="/bulk-eligibility"
        element={
          <ProtectedRoute>
            <BulkEligibility />
          </ProtectedRoute>
        }
      />
      <Route
        path="/eob-upload"
        element={
          <ProtectedRoute>
            <div style={{ padding: "24px" }}>EOB Upload Page</div>
          </ProtectedRoute>
        }
      />
      <Route
        path="/encounters"
        element={
          <ProtectedRoute>
            <PreBillingClaim />
          </ProtectedRoute>
        }
      />
      <Route
        path="/post-billing-claim-page"
        element={
          <ProtectedRoute>
            <PostBillingClaimPage />
          </ProtectedRoute>
        }
      />
      <Route
        path="/new-payment"
        element={
          <ProtectedRoute>
            <NewPayment />
          </ProtectedRoute>
        }
      />
      <Route
        path="/encounter-list"
        element={
          <ProtectedRoute>
            <div style={{ padding: "24px" }}>Encounter List Page</div>
          </ProtectedRoute>
        }
      />
      <Route
        path="/era"
        element={
          <ProtectedRoute>
            <div style={{ padding: "24px" }}>ERA Page</div>
          </ProtectedRoute>
        }
      />
      <Route
        path="/collections"
        element={
          <ProtectedRoute>
            <div style={{ padding: "24px" }}>Collections Page</div>
          </ProtectedRoute>
        }
      />
      <Route
        path="/icd-10-search"
        element={
          <ProtectedRoute>
            <div style={{ padding: "24px" }}>ICD 10 Search Page</div>
          </ProtectedRoute>
        }
      />
      <Route
        path="/excel-access"
        element={
          <ProtectedRoute>
            <div style={{ padding: "24px" }}>Excel Access Page</div>
          </ProtectedRoute>
        }
      />
      <Route
        path="/reports"
        element={
          <ProtectedRoute>
            <div style={{ padding: "24px" }}>Reports Page</div>
          </ProtectedRoute>
        }
      />
      <Route
        path="/documents"
        element={
          <ProtectedRoute>
            <div style={{ padding: "24px" }}>Documents Page</div>
          </ProtectedRoute>
        }
      />

      {/* ---------- Edit pages ---------- */}

            <Route
        path="/new-encounter"
        element={
          <ProtectedRoute>
            <NewEncounter />
          </ProtectedRoute>
        }
      />
           <Route
        path="/pre-billing-edit/:id"
        element={
          <ProtectedRoute>
            <NewEncounter />
          </ProtectedRoute>
        }
      />
      <Route
        path="/pre-billing-claim-page"
        element={
          <ProtectedRoute>
            <PreBilling />
          </ProtectedRoute>
        }
      />
      <Route
        path="/post-billing-edit/:id"
        element={
          <ProtectedRoute>
            <PostBillingEditPage />
          </ProtectedRoute>
        }
      />
      <Route
        path="/remittance-era-edit/:id"
        element={
          <ProtectedRoute>
            <RemittanceERAEdit />
          </ProtectedRoute>
        }
      />
    </Routes>
  );
};

export default AppRoutes;
